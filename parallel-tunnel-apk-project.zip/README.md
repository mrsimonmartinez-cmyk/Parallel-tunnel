# The Parallel Tunnel (APK project)

The game is app/src/main/assets/index.html. To change the game, replace that file.

Build the APK:
- Android Studio: open this folder, then Build > Build APK(s).
- GitHub: push this folder to a repo, open the Actions tab, run "Build APK", then download the parallel-tunnel-apk artifact.
